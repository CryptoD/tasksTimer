if (typeof Utils !== 'undefined' && typeof Utils.isGnome40 !== 'function') {
    Utils.isGnome40 = function() {
        try {
            const Config = imports.misc.config;
            const [major] = Config.PACKAGE_VERSION.split('.');
            const shellVersion = Number.parseInt(major);
            return (shellVersion >= 40);
        } catch (e) {
            return true;
        }
    };
}

// Existing code continues here...
this.logger = new Logger('kt prefs', this._settings);

// Safety check for Utils.isGnome40 function
const isGnome40 = typeof Utils.isGnome40 === 'function' ? Utils.isGnome40 : function() {
    // Fallback implementation
    try {
        const Config = imports.misc.config;
        const [major] = Config.PACKAGE_VERSION.split('.');
        const shellVersion = Number.parseInt(major);
        return (shellVersion >= 40);
    } catch (e) {
        // Default to true for newer versions
        return true;
    }
};

if (isGnome40()) {
    let iconPath = Me.dir.get_child("icons").get_path();
    let iconTheme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default());
    iconTheme.add_search_path(iconPath);
} else {
    // For GNOME 3.x
    let iconPath = Me.dir.get_child("icons").get_path();
    let iconTheme = Gtk.IconTheme.get_default();
    iconTheme.append_search_path(iconPath);
}